import java.util.*;
public class Main
{
	public static void main(String[] args) {
		String a="123456789";
		String b="987654321";
		int n=a.length();
		int m=b.length();
		int prod[]=new int[n+m];
		for(int i=n-1;i>=0;i--){
		    for(int j=m-1;j>=0;j--){
		        int c=a.charAt(i)-'0';
		        int d=b.charAt(j)-'0';
		        prod[i+j+1]+=c*d;
		    }
		}
		int carry=0;
		for(int i=prod.length-1;i>=0;i--){
		    int temp=(prod[i]+carry)%10;
		    carry=(prod[i]+carry)/10;
		    prod[i]=temp;
		}
		StringBuilder str=new StringBuilder();
		 for(int i:prod)str.append(i);
		 while(str.length()!=0 &&str.charAt(0)=='0')str.deleteCharAt(0);
		 System.out.println(str.toString());
		 
	}
}
